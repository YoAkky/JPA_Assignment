package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.IBookingService;

@Controller
public class BookingController {
	
	@Autowired
	private IBookingService bookingService;
	
	@RequestMapping("/index.obj")
	public String getHomePage(Model model){
		model.addAttribute("hotelDetailsList", bookingService.showAllHotelDetails());
		return "HotelDetails";
	}
	
	@RequestMapping("/displayHotelDetails.obj")
	public String showHotelDetails(Model model){
		System.out.println(bookingService.showAllHotelDetails());
		
		return "displayHotelDetails.obj";
	}
	
	@RequestMapping("/contrBookingConfirmation.obj")
	public String showHotelDetails(@RequestParam String name, Model model){
		
		
		return "contrBookingConfirmation";
	}
	
}
