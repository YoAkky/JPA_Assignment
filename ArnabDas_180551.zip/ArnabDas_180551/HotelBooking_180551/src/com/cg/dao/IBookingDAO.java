package com.cg.dao;

import java.util.List;

import com.cg.bean.HotelDetails;

public interface IBookingDAO {
	public List<HotelDetails> showAllHotelDetails();
}
